<template>
    <main-view @open="openFolder">

        <!--///// WELCOME /////-->
        <folder-view :folderState="content['welcome'].state" @folderState="closeFolder('welcome')" title="Welcome to 2k Finance">
            <welcome @open="openFolder" @close="closeFolder"></welcome>
        </folder-view>

        <!--///// ABOUT /////-->
        <folder-view :folderState="content['about'].state" @folderState="closeFolder('about')" title="About 2k Finance">
            <about></about>
        </folder-view>

        <!--///// MY WALLET /////-->
        <folder-view :folderState="content['my-wallet'].state" @folderState="closeFolder('my-wallet')" title="My Wallet" sectioned noScroll>
            <my-wallet></my-wallet>
        </folder-view>

        <!--///// VAULT /////-->
        <folder-view :folderState="content['vault'].state" @folderState="closeFolder('vault')" title="2k Vaults" sectioned fixedSection>
            <vault @open="openFolder"></vault>
        </folder-view>

        <!--///// TWOK BNB LP /////-->
        <folder-view :folderState="content['twok-bnb-lp'].state" @folderState="closeFolder('twok-bnb-lp')" title="TWOK / BNB LP" sectioned fixedSection>
            <twok-bnb-lp @open="openFolder"></twok-bnb-lp>
        </folder-view>

        <!--///// GOVERNANCE /////-->
        <folder-view :folderState="content['governance'].state" @folderState="closeFolder('governance')" title="2k Finance Governance" sectioned fixedSection>
            <governance @open="openFolder"></governance>
        </folder-view>

        <!--///// TWOKPROPOSALS /////-->
        <folder-view :folderState="content['twokproposals'].state" @folderState="closeFolder('twokproposals')" title="2k Finance Proposals" sectioned fixedSection>
            <twokproposals @open="openFolder"></twokproposals>
        </folder-view>

        <!--///// DEXMOONPROPOSALS /////-->
        <folder-view :folderState="content['dexmoonproposals'].state" @folderState="closeFolder('dexmoonproposals')" title="DexMoon Proposals" sectioned fixedSection>
            <dexmoonproposals @open="openFolder"></dexmoonproposals>
        </folder-view>

        <!--///// CHARTS /////-->
        <folder-view :folderState="content['charts'].state" @folderState="closeFolder('charts')" title="2k Charts" sectioned fixedSection>
            <charts @open="openFolder"></charts>
        </folder-view>

        <!--///// CONNECT WALLET /////-->
        <folder-view :folderState="content['connect-wallet'].state" @folderState="closeFolder('connect-wallet')" title="Connect to a wallet" sectioned fixedSection>
            <connect-wallet></connect-wallet>
        </folder-view>

        <!--///// INFORMATION /////-->
        <folder-view :folderState="content['information'].state" @folderState="closeFolder('information')" title="2k Finance Information">
            <information></information>
        </folder-view>

        <!--///// PROJECT /////-->
        <folder-view :folderState="content['project'].state" @folderState="closeFolder('project')" title="Project Name" sectioned>
            <project></project>
        </folder-view>
        
        <!--///// CREATE PROJECT /////-->
        <folder-view :folderState="content['create-project'].state" @folderState="closeFolder('create-project')" title="Register a Project">
            <create-project @close="closeFolder"></create-project>
        </folder-view>

        <!--///// CREATE PROPOSAL /////-->
        <folder-view :folderState="content['create-proposal'].state" @folderState="closeFolder('create-proposal')" title="Create Proposal">
            <create-proposal @close="closeFolder"></create-proposal>
        </folder-view>

        <!--///// CONFIRMATION /////-->
        <folder-view :folderState="content['confirmation'].state" @folderState="closeFolder('confirmation')" title="Confirmation">
            <confirmation @open="openFolder"></confirmation>
        </folder-view>
    </main-view>
</template>
<script>
import './assets/css/colours.css';
import './assets/css/global.css';
import './assets/fonts/geneva/geneva.css';
import './assets/fonts/chicagoFLF/chicagoFLF.css';
import mainView from "@/components/mainView";
import folderView from "@/components/folderView";
import welcome from "@/pages/welcome";
import about from "@/pages/about";
import connectWallet from "@/pages/connect-wallet";
import information from "@/pages/information";
import myWallet from "@/pages/my-wallet";
import vault from "@/pages/vault";
import twokBnbLp from "@/pages/twok-bnb-lp";
import Confirmation from "@/pages/confirmation";
import Governance from "@/pages/governance";
import Twokproposals from "@/pages/twokproposals";
import dexmoonproposals from "@/pages/dexmoonproposals"
import Project from "@/pages/project";
import Charts from "@/pages/charts";
import CreateProject from "@/pages/create-project";
import CreateProposal from "@/pages/create-proposal";
export default {
    name: "App",
    data: () => ({
        folderState: true,
        content: {
            "welcome":{
                state: true,
            },
            "about":{
                state: false,
            },
            "my-wallet":{
                state: false,
            },
            "vault":{
                state: false,
            },
            "twok-bnb-lp":{
                state: false,
            },
            "governance":{
                state: false,
            },
            "charts":{
                state: false,
            },
            "connect-wallet":{
                state: false,
            },
            "information":{
                state: false,
            },
            "project":{
                state: false,
            },
            "twokproposals":{
                state: false,
            },
            "dexmoonproposals":{
                state: false,
            },
            "create-project":{
                state: false,
            },
            "create-proposal":{
                state: false,
            },
            "confirmation":{
                state: false,
            },
        },
    }),
    components: {
        CreateProject,
        CreateProposal,
        Charts,
        Project,
        Twokproposals,
        dexmoonproposals,        
        Governance,        
        Confirmation,
        twokBnbLp, vault, myWallet, information, connectWallet, about, welcome, folderView, mainView},
    methods: {
        closeFolder(key){
            this.content[key].state = false;
        },
        openFolder(key){
            for(let i in this.content){
                this.content[i].state = false;
            }
            this.content[key].state = true;
        },
    }
}
</script>

<style scoped>

</style>
