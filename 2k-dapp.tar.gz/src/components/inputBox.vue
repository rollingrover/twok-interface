<template>
    <section class="kk-input">
        <input :type="type" :placeholder="placeholder">
    </section>
</template>

<script>
export default {
    name: "inputBox",
    props: {
        type: String,
        placeholder: String,
    },
}
</script>

<style scoped>
    .kk-input {height: 35px; outline: 3px solid rgba(var(--secondary), 1); margin: 1.5px; font-family: 'Geneva', sans-serif; font-size: 0;}
    .kk-input input {
        width: 100%;
        box-sizing: border-box;
        border: none;
        box-shadow: none;
        outline: none;
        font-family: inherit;
        height: 100%;
        background-color: transparent;
        padding: 0 15px;
        font-size: 1rem;
        color: rgba(var(--secondary), 1);
    }

    .kk-input input::placeholder {color: rgba(var(--secondary), 0.5); font-size: 1rem; font-family: inherit;}
</style>