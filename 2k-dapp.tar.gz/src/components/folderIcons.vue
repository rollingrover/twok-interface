<template>
    <section class="kk-icons">
        <div class="kk-icons-list">
            <div v-for="(iconItem, index) in iconItems" :key="index" class="kk-icons-item">
                <a :href="iconItem.href" class="kk-icons-link" target="_blank">
                    <div class="kk-icons-icon TSE-opacity">
                        <img :src="require('../assets/images/' + iconItem.icon)" alt="icon"/>
                    </div>
                    <div class="kk-icons-txt">
                        <span>{{ iconItem.title }}</span>
                    </div>
                </a>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: "folderIcons",
    props: {
        iconItems: Array,
    },
}
</script>

<style scoped>
    .kk-icons {position: relative; max-width: 500px; margin: 0 auto; margin-bottom: 50px;}
    .kk-icons-list {display: flex; flex-flow: row wrap; justify-content: space-around; align-items: flex-start;}
    .kk-icons-item {margin: 10px;}
    .kk-icons-link {display: block; font-size: 0; text-align: center;}
    .kk-icons-icon {margin-bottom: 15px; width: 80px; display: inline-block;}
    .kk-icons-link:hover .kk-icons-icon {opacity: 0.6;}
    .kk-icons-txt {text-align: center; font-size: 1rem; color: rgba(var(--secondary), 1);}

    /*/////////////////////////////////*/
    /*/////////// RESPONSIVE //////////*/
    /*/////////////////////////////////*/

    @media (min-width: 1450px){
        .kk-icons-icon {width: 90px;}
        .kk-icons {margin-top: 20px; margin-bottom: 80px; max-width: 650px;}
    }
</style>