<template>
    <section>
        <div class="dynCont">
            <h2>Great News</h2>
            <p>Your stake was successfully completed. Your coins are floating through the internet as we speak.</p>
            <h5>Available Earnings: <span id="twokEarnings">0.00</span> TWOK</h5>
            <h5>Currently Staked: 0 TWOK / BNB LP</h5>
            <div class="btnGroup">
                <generic-button @clicked="open('vault')" title="Vaults"></generic-button>
                <generic-button href="#" title="Buy TWOK"></generic-button>
            </div>
        </div>
    </section>
</template>

<script>
import GenericButton from "@/components/genericButton";
export default {
    name: "confirmation",
    components: {GenericButton},
    methods: {
        open(key) {
            this.$emit("open", key);
        },
    },
}
</script>

<style scoped>

</style>