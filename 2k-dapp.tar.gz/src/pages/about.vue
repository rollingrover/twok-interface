<template>
    <section>
        <div class="dynCont">
            <h2>About Us</h2>
            <p>
                We are a group of crypto enthusiasts, and developers from around the globe building fun and
                experimental projects. Our first of many projects is 2K (TwoK). A deflationary yield farming
                protocol built on the Binance Smart Chain.
            </p>
            <h2>Tokenomics</h2>
            <p>
                It's simple and elegant 2K has a minimal supply of 2,000 TWOK tokens ever to be minted that is
                deflationary at its core.
            </p>
            <h2>Minimal Supply</h2>
            <p>
                2,000 TWOK tokens were minted with no ability to create more tokens. With a supply this low there
                are huge gains to be made off just one token. The only way for more tokens to circulate is through
                earning TWOK by staking in our vault.
            </p>
            <h2>Deflationary</h2>
            <p>
                While our token has an extremely low supply we're also deflationary. Every time a weak hand sells a
                1% fee is taken from that transaction and allocated in two ways. First, 0.9% is transferred back to
                the vault emisisons wallet and 0.1% of that is burned forever.
            </p>
        </div>
    </section>
</template>

<script>
export default {
    name: "about"
}
</script>

<style scoped>

</style>