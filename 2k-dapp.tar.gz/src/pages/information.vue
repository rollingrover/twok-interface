<template>
    <section>
        <div class="dynCont">
            <p>
                STAKING IS LIVE !!!<br>
                We hope you enjoy your stay with us.<br>
                Get to know us in the chat.<br>
                Feel free to ask us anything about the project.<br>
                And we hope you enjoy your stay with us.<br>
                Get familiar read the info below.<br>
                See you soon
            </p>
            <ul>
                <li class="noBullet">⚪️ Tokenomics:</li>
                <li>Name: 2K finance</li>
                <li>Ticker: TwoK</li>
                <li>Total Supply: 1990</li>
                <li>Circulating Supply: 1300.76</li>
                <li>Rewards : 689.25</li>
                <li>Tokens burned 10</li>
                <li>Website 2k.rocks</li>
                <li>dAPP is live</li>
            </ul>
            <p>
                dAPP info: Stake your BNB tokens and receive rewards in TwoK tokens.
                We launched the staking dAPP with a 350% APY
            </p>
            <p>
                1% fee per TX. 10% burned permanently and 90% to rewards emissions.
            </p>
            <p>
                Check the TwoK Chart for analysis:https://goswapp-bsc.web.app/0xae1e69bbd3dc0c470ce4ba28794753cdfdec7452
            </p>
            <p>
                Pancake Swap: https://exchange.pancakeswap.finance/#/swap?inputCurrency=ETH&outputCurrency=0xae1e69bbd3dc0c470ce4ba28794753cdfdec7452
            </p>
            <p>
                BSC Scan Token: https://bscscan.com/token/0xae1e69bbd3dc0c470ce4ba28794753cdfdec7452
            </p>
            <p>
                Token Burned: https://bscscan.com/tx/0x85adf36b7fb601c41d54fad49ad35fa6322d9c802f49f400d9bf893e13b68cc5
            </p>
            <p>
                Audit Report<br>
                https://solidity.finance/audits/TWOK/ https://solidity.finance/audits/1k/
                Same contracts as 1K Finance with minor tweaks.
            </p>
            <p>
                Never used Binance Smart chain before? Please follow this guide:
                https://coinguides.org/binance-smart-chain-metamask/#:~:text=1%20On%20your%20MetaMask%20wallet%20drop%20down%20your,network.%203%20Now%20enter%20the%20details%20as%20follows
            </p>    
            
        </div>
    </section>
</template>

<script>
export default {
    name: "information"
}
</script>

<style scoped>

</style>