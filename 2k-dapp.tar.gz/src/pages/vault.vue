<template>
    <section class="kk-section">
        <div class="kk-section-top">
            <div class="dynCont left">
                <span class="kk-h5 ma-0">10 Items</span>
            </div>
        </div>
        <div class="kk-section-cont">
            <icon-grid :grid-items="gridItems" @open="open"></icon-grid>
        </div>
    </section>
</template>

<script>
import iconGrid from "@/components/iconGrid";
export default {
name: "vault",
    components: {iconGrid},
    methods: {
        open(key) {
            this.$emit("open", key);
        }
    },
    data: () => ({
        gridItems: [
            {
                title: "TWOK / BNB LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK Vault",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "BNB Vault",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "USDT/BUSD LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK / DAI LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK / USDT LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK / BTC LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK / ETH LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK / IOTX LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
            {
                title: "TWOK / IOST LP",
                icon: "vault-icon.png",
                key: "twok-bnb-lp",
            },
        ],
    })
}
</script>

<style scoped>

</style>