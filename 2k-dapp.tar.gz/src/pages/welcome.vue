<template>
    <section>
        <div class="dynCont center">
            <h2>Low Supply, Deflationary, Yield Farming</h2>
            <p>
                We're building a deflationary yield farming protocol on the Binance Smart Chain.
                Stake BNB/TWOK LP tokens, earn TWOK.
            </p>
            <div class="btnGroup flex mw-500">
                <generic-button @clicked="close('welcome')" title="Cancel"></generic-button>
                <generic-button href="#" title="Buy TWOK"></generic-button>
                <generic-button @clicked="open('connect-wallet')" title="Connect Wallet"></generic-button>
            </div>
        </div>
    </section>
</template>

<script>
import genericButton from "@/components/genericButton";
export default {
    name: "welcome",
    components: {genericButton},
    methods: {
        open(key) {
            this.$emit("open", key);
        },
        close(key) {
            this.$emit("close", key);
        }
    },
}
</script>

<style scoped>

</style>